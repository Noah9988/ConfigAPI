package me.olli.utils.config.exceptions;

public class EntryNotFoundException extends NullPointerException {

	public EntryNotFoundException(String s) {
		super(s);
	}

	private static final long serialVersionUID = -1299488080188410482L;

	/**
	 * penis
	 */

}
